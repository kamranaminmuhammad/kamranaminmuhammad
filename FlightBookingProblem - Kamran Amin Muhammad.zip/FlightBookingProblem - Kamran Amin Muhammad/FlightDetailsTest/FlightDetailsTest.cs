using System;
using Xunit;
using FlightBooking.Core;

namespace FlightDetailsTest
{
    public class FlightDetailsTest
    {
        TestFunctions TestFunctions = new TestFunctions();

        [Fact]
        public void CheckProfitsAndCosts()
        {
            var spainToItaly = new FlightRoute("Spain", "Italy")
            {
                BaseCost = 80,
                BasePrice = 150,
                LoyaltyPointsGained = 10,
                MinimumTakeOffPercentage = 0.5
            };

            TestFunctions.addFlightData(spainToItaly);

            var costOfFlight = TestFunctions.GetCostOfFlight(spainToItaly);

            var totalPriceForGeneral = TestFunctions.GetTotalPriceForGeneral(spainToItaly);
            var totalPriceForNonUsingLoyaltyPoints = TestFunctions.GetTotalPriceForNonUsingLoyaltyPoints(spainToItaly);
            var totalPriceForDiscounted = TestFunctions.GetTotalPriceForDiscounted(spainToItaly);

            var profitFromFlight = (totalPriceForGeneral + totalPriceForNonUsingLoyaltyPoints + totalPriceForDiscounted) - costOfFlight;

            Assert.Equal(350, costOfFlight);
            Assert.Equal(100, profitFromFlight);
        }

        [Fact]
        public void CheckBookedSeats()
        {
            setupTestData();

            int seatsTaken = TestFunctions.getBookedSeats();

            Assert.Equal(7, seatsTaken);

        }

        [Fact]
        public void GetGeneralPassengersCount()
        {
            setupTestData();

            int seatsTaken = TestFunctions.GetPassengersCountByType(PassengerType.General);

            Assert.Equal(3, seatsTaken);

        }

        public void GetDiscountedPassengersCount()
        {
            setupTestData();

            int seatsTaken = TestFunctions.GetPassengersCountByType(PassengerType.Discounted);

            Assert.Equal(1, seatsTaken);

        }

        public void GetLoyaltyPassengersCount()
        {
            setupTestData();

            int seatsTaken = TestFunctions.GetPassengersCountByType(PassengerType.Discounted);

            Assert.Equal(2, seatsTaken);

        }

        public void GetAirlineEmployeeAsPassengersCount()
        {
            setupTestData();

            int seatsTaken = TestFunctions.GetPassengersCountByType(PassengerType.Discounted);

            Assert.Equal(1, seatsTaken);

        }

        private void setupTestData()
        {
            var spainToItaly = new FlightRoute("Spain", "Italy")
            {
                BaseCost = 80,
                BasePrice = 150,
                LoyaltyPointsGained = 10,
                MinimumTakeOffPercentage = 0.5
            };

            TestFunctions.addFlightData(spainToItaly);
        }
    }
}
