﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlightBooking.Core
{
    class Rule
    {
        public int RuleId { get; set; }

        public string RuleName { get; set; }

        public string RuleValue1 { get; set; }

        public string RuleValue2 { get; set; }

        public Operator Operator { get; set; }

        public RuleDataType DataType { get; set; }
        public RuleType RuleType { get; set; }

    }

    public enum RuleType
    {
        Default,
        Relaxed
    }

    public enum RuleDataType
    {
        String,
        Integer,
        Double
    }

    public enum Operator
    {
        EqualsTo,
        LessThan,
        LessThanAndEqualsTo,
        GreaterThan,
        GreaterThanAndEqualsTo
    }
}
