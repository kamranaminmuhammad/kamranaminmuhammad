﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace FlightBooking.Core
{
    public class ScheduledFlight
    {
        private readonly string VERTICAL_WHITE_SPACE = Environment.NewLine + Environment.NewLine;
        private readonly string NEW_LINE = Environment.NewLine;
        private const string INDENTATION = "    ";
        public FlightRoute FlightRoute { get; private set; }
        public Plane Aircraft { get; private set; }

        public List<Plane> AircraftsList = new List<Plane>();
        public List<Passenger> Passengers { get; private set; }

        public ScheduledFlight(FlightRoute flightRoute)
        {
            FlightRoute = flightRoute;
            Passengers = new List<Passenger>();
        }

        public Passenger CreatePassengerObject(PassengerType type, string name, int age, int loyaltyPoints = 0, Boolean isUsingLoyaltyPoints = false)
        {
            return new Passenger
            {
                Type = type,
                Name = name,
                Age = age,
                LoyaltyPoints = loyaltyPoints,
                IsUsingLoyaltyPoints = isUsingLoyaltyPoints
            };
        }

        public void AddPassenger(Passenger passenger)
        {
            Passengers.Add(passenger);
        }

        public List<Passenger> GetPassengers()
        {
            return Passengers;
        }

        public void SetAircraftForRoute(Plane aircraft)
        {
            Aircraft = aircraft;
        }

        private void SetValuesForGeneralPassenger(ref double profitFromFlight, ref int totalExpectedBaggage)
        {
            profitFromFlight += FlightRoute.BasePrice;
            totalExpectedBaggage++;
        }

        private void SetValuesForLoyaltyMembers(ref bool IsUsingLoyaltyPoints, ref int passengerLoyaltyPoints,
            ref int totalLoyaltyPointsRedeemed, ref int totalLoyaltyPointsAccrued, ref int totalExpectedBaggage, ref double profitFromFlight)
        {
            if (IsUsingLoyaltyPoints)
            {
                int loyaltyPointsRedeemed = Convert.ToInt32(Math.Ceiling(FlightRoute.BasePrice));
                passengerLoyaltyPoints -= loyaltyPointsRedeemed;
                totalLoyaltyPointsRedeemed += loyaltyPointsRedeemed;
            }
            else
            {
                totalLoyaltyPointsAccrued += FlightRoute.LoyaltyPointsGained;
                profitFromFlight += FlightRoute.BasePrice;
            }
            totalExpectedBaggage += 2;
        }

        private void SetValuesForAirlineEmployee(ref int totalExpectedBaggage)
        {
            totalExpectedBaggage++;
        }

        private void SetValuesForDiscounted(ref double profitFromFlight)
        {
            profitFromFlight += FlightRoute.BasePrice / 2;
        }

        private string GenerateSumamry(int seatsTaken, int totalExpectedBaggage, double profitFromFlight, double costOfFlight, int totalLoyaltyPointsAccrued, int totalLoyaltyPointsRedeemed, bool applyRelaxedRules)
        {
            string result = "Flight summary for " + FlightRoute.Title;
            int airLineEmployeesAboard = Passengers.Count(p => p.Type == PassengerType.AirlineEmployee);

            result += VERTICAL_WHITE_SPACE;

            result += "Total passengers: " + seatsTaken;
            result += NEW_LINE;
            result += INDENTATION + "General sales: " + Passengers.Count(p => p.Type == PassengerType.General);
            result += NEW_LINE;
            result += INDENTATION + "Loyalty member sales: " + Passengers.Count(p => p.Type == PassengerType.LoyaltyMember);
            result += NEW_LINE;
            result += INDENTATION + "Airline employee comps: " + airLineEmployeesAboard;

            result += NEW_LINE;
            result += INDENTATION + "Discounted comps: " + Passengers.Count(p => p.Type == PassengerType.Discounted);

            result += VERTICAL_WHITE_SPACE;
            result += "Total expected baggage: " + totalExpectedBaggage;

            result += VERTICAL_WHITE_SPACE;

            result += "Total revenue from flight: " + profitFromFlight;
            result += NEW_LINE;
            result += "Total costs from flight: " + costOfFlight;
            result += NEW_LINE;

            double profitSurplus = profitFromFlight - costOfFlight;
            int requiredPassengers = Convert.ToInt32(Aircraft.NumberOfSeats * FlightRoute.MinimumTakeOffPercentage);

            result += (profitSurplus > 0 ? "Flight generating profit of: " : "Flight losing money of: ") + profitSurplus;

            result += VERTICAL_WHITE_SPACE;

            result += "Total loyalty points given away: " + totalLoyaltyPointsAccrued + NEW_LINE;
            result += "Total loyalty points redeemed: " + totalLoyaltyPointsRedeemed + NEW_LINE;

            result += VERTICAL_WHITE_SPACE;

            BusinessRules Rules = new BusinessRules();
            if (Rules.RulesExecutedSuccessfully(profitSurplus, seatsTaken, Aircraft.NumberOfSeats, FlightRoute, airLineEmployeesAboard, costOfFlight, requiredPassengers, applyRelaxedRules)) {
                result += "THIS FLIGHT MAY PROCEED";
            }
            else
            {
                result += "FLIGHT MAY NOT PROCEED";
                result += VERTICAL_WHITE_SPACE;

                if (seatsTaken > Aircraft.NumberOfSeats)
                {
                    var RemainingAircrafts = AircraftsList.Where(o => o.Id != Aircraft.Id).ToList();
                    if(RemainingAircrafts.Count > 0)
                    {
                        result += "Other more suitable aircraft are: ";
                        result += NEW_LINE;
                    }

                    for (int count = 0; count < RemainingAircrafts.Count; count++)
                    {
                        result += AircraftsList[count].Name + " could handle this flight.";
                        result += NEW_LINE;
                    }
                }

            }

            return result;
        }

        public string GetSummary(bool applyRelaxedRules)
        {
            double costOfFlight = 0;
            double profitFromFlight = 0;
            int totalLoyaltyPointsAccrued = 0;
            int totalLoyaltyPointsRedeemed = 0;
            int totalExpectedBaggage = 0;
            int seatsTaken = 0;

            foreach (var passenger in Passengers)
            {
                switch (passenger.Type)
                {
                    case (PassengerType.General):
                        {
                            SetValuesForGeneralPassenger(ref profitFromFlight, ref totalExpectedBaggage);
                            break;
                        }
                    case (PassengerType.LoyaltyMember):
                        {
                            bool isUsingLoyaltyPoints = passenger.IsUsingLoyaltyPoints;
                            int passengerLoyaltyPoints = passenger.LoyaltyPoints;
                            SetValuesForLoyaltyMembers(ref isUsingLoyaltyPoints, ref passengerLoyaltyPoints, ref totalLoyaltyPointsRedeemed, ref totalLoyaltyPointsAccrued, ref totalExpectedBaggage, ref profitFromFlight);
                            passenger.LoyaltyPoints = passengerLoyaltyPoints;
                            break;
                        }
                    case (PassengerType.AirlineEmployee):
                        {
                            SetValuesForAirlineEmployee(ref totalExpectedBaggage);
                            break;
                        }
                    case (PassengerType.Discounted):
                        {
                            SetValuesForDiscounted(ref profitFromFlight);
                            break;
                        }
                }
                costOfFlight += FlightRoute.BaseCost;
                seatsTaken++;
            }

            return GenerateSumamry(seatsTaken, totalExpectedBaggage, profitFromFlight, costOfFlight, totalLoyaltyPointsAccrued, totalLoyaltyPointsRedeemed, applyRelaxedRules);
        }


    }
}
