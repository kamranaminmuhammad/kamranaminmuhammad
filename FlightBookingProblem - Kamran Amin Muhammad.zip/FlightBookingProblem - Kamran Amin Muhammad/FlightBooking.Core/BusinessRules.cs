﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlightBooking.Core
{
    class BusinessRules
    {
        public List<Rule> Rules = new List<Rule>();

        public void GetRules(double profitSurplus, int seatsTaken, int AirCraftTotalSeats, FlightRoute flightRoute, int airLineEmployeesAboard, double costOfFlight, int requiredPassengers)
        {
            Rules.Add(new Rule { RuleId = 1, RuleName= "profitSurplus > 0", Operator = Operator.GreaterThan, RuleValue1= profitSurplus.ToString(), RuleValue2="0", DataType=RuleDataType.Integer, RuleType = RuleType.Default  });
            Rules.Add(new Rule { RuleId = 2, RuleName = "seatsTaken < AirCraftTotalSeats", Operator = Operator.LessThan, RuleValue1 = seatsTaken.ToString(), RuleValue2 = AirCraftTotalSeats.ToString(), DataType = RuleDataType.Integer, RuleType = RuleType.Default });
            Rules.Add(new Rule { RuleId = 3, RuleName = "seatsTaken / (double)AirCraftTotalSeats > flightRoute.MinimumTakeOffPercentage", Operator = Operator.GreaterThan, RuleValue1 = (seatsTaken/(double)AirCraftTotalSeats).ToString(), RuleValue2 = flightRoute.MinimumTakeOffPercentage.ToString(), DataType = RuleDataType.Double, RuleType = RuleType.Default });
            Rules.Add(new Rule { RuleId = 4, RuleName = " number of airline employees aboard is greater than the minimum percentage of passengers required", Operator = Operator.GreaterThan, RuleValue1 = (airLineEmployeesAboard/(double)requiredPassengers).ToString(), RuleValue2 = flightRoute.MinimumTakeOffPercentage.ToString(), DataType = RuleDataType.Double, RuleType = RuleType.Relaxed });
            Rules.Add(new Rule { RuleId = 5, RuleName = "the revenue generated doesn’t need to exceed cost", Operator = Operator.GreaterThan, RuleValue1 = profitSurplus.ToString(), RuleValue2 = costOfFlight.ToString(), DataType = RuleDataType.Double, RuleType = RuleType.Relaxed });
        }

        public bool DefaultRulesPassed(double profitSurplus, int seatsTaken, int AirCraftTotalSeats, FlightRoute flightRoute)
        {
            List<Rule> defaultRules = Rules.Where(o => o.RuleType == RuleType.Default).ToList();
            bool isSuccess = true;
            RulePassedSuccessfully(ref isSuccess, defaultRules);
            return isSuccess;
        }

        public bool RelaxedRulesPassed(double profitSurplus, int seatsTaken, int AirCraftTotalSeats, FlightRoute flightRoute, int airLineEmployeesAboard)
        {
            List<Rule> relaxedRules = Rules.Where(o => o.RuleType == RuleType.Relaxed).ToList();
            bool isSuccess = true;
            RulePassedSuccessfully(ref isSuccess, relaxedRules);
            return isSuccess;
        }

        public bool RulesExecutedSuccessfully(double profitSurplus, int seatsTaken, int airCraftTotalSeats, FlightRoute flightRoute, int airLineEmployeesAboard, double costOfFlight,int requiredPassengers, bool applyRelaxedRules)
        {
            try
            {
                GetRules(profitSurplus, seatsTaken, airCraftTotalSeats, flightRoute, airLineEmployeesAboard, costOfFlight, requiredPassengers);
                if (applyRelaxedRules)
                {
                    if (RelaxedRulesPassed(profitSurplus, seatsTaken, airCraftTotalSeats, flightRoute, airLineEmployeesAboard))
                    {
                        return true;
                    }
                }
                else
                {
                    if (DefaultRulesPassed(profitSurplus, seatsTaken, airCraftTotalSeats, flightRoute))
                    {
                        return true;
                    }
                }
            }
            catch(Exception)
            {
                return false;
            }
            return false;
        }

        private void RulePassedSuccessfully(ref bool isSuccess, List<Rule> defaultRules)
        {
            for (int count = 0; count < defaultRules.Count; count++)
            {
                if (!IsRuleSuccess(defaultRules[count]))
                {
                    isSuccess = false;
                    break;
                }
            }
        }

        private bool IsRuleSuccess(Rule rule)
        {
            dynamic value1;
            dynamic value2;

            if(rule.DataType == RuleDataType.Double)
            {
                value1 = Convert.ChangeType(rule.RuleValue1, typeof(double));
                value2 = Convert.ChangeType(rule.RuleValue2, typeof(double));
            }
            else if (rule.DataType == RuleDataType.Integer)
            {
                value1 = Convert.ChangeType(rule.RuleValue1, typeof(int));
                value2 = Convert.ChangeType(rule.RuleValue2, typeof(int));
            }
            else
            {
                value1 = rule.RuleValue1;
                value2 = rule.RuleValue2;
            }

            switch (rule.Operator)
            {
            case (Operator.LessThan):
                {
                    return value1 <= value2;
                }
            case (Operator.LessThanAndEqualsTo):
                {
                    return value1 <= value2;
                }
            case (Operator.GreaterThan):
                {
                    return value1 > value2;
                }
            case (Operator.GreaterThanAndEqualsTo):
                {
                    return value1 >= value2;
                }
            case (Operator.EqualsTo):
                {
                    return value1 == value2;
                }
            }

            return false;
        }

        private object GetConvertedValue(string value, RuleDataType dataType)
        {
            if(dataType == RuleDataType.Double)
            {
                var val1 = Convert.ChangeType(value, typeof(double));
                return val1;
            }
            else if(dataType == RuleDataType.Integer)
            {
                var val1 = Convert.ChangeType(value, typeof(int));
                return val1;
            }
            else
            {
                return value;
            }
        }
    }
}
