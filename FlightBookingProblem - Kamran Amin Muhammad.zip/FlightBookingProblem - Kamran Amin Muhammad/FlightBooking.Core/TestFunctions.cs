﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlightBooking.Core
{
    public class TestFunctions
    {
        private static ScheduledFlight _scheduledFlight;

        private static void SetupAirlineData()
        {
            FlightRoute londonToParis = new FlightRoute("London", "Paris")
            {
                BaseCost = 50,
                BasePrice = 100,
                LoyaltyPointsGained = 5,
                MinimumTakeOffPercentage = 0.7
            };

            _scheduledFlight = new ScheduledFlight(londonToParis);

            // Adding Aircraft List 
            _scheduledFlight.AircraftsList.Add(new Plane { Id = 123, Name = "Antonov AN-2", NumberOfSeats = 12 });
            _scheduledFlight.AircraftsList.Add(new Plane { Id = 124, Name = "Bombardier Q400", NumberOfSeats = 16 });
            _scheduledFlight.AircraftsList.Add(new Plane { Id = 125, Name = "ATR 640", NumberOfSeats = 12 });

            _scheduledFlight.SetAircraftForRoute(_scheduledFlight.AircraftsList[0]);
        }
        public double GetCostOfFlight(FlightRoute FlightRoute)
        {
            return _scheduledFlight.Passengers.Count * FlightRoute.BaseCost;
        }

        public double GetTotalPriceForGeneral(FlightRoute Flight)
        {
            return _scheduledFlight.Passengers.Where(p => p.Type == PassengerType.General).Count() * Flight.BasePrice;
        }

        public double GetTotalPriceForNonUsingLoyaltyPoints(FlightRoute Flight)
        {
            return _scheduledFlight.Passengers.Where(p => p.Type == PassengerType.LoyaltyMember && p.IsUsingLoyaltyPoints == false).Count() * Flight.BasePrice;
        }

        public double GetTotalPriceForDiscounted(FlightRoute Flight)
        {
            return (_scheduledFlight.Passengers.Where(p => p.Type == PassengerType.Discounted).Count() * Flight.BasePrice) / 2;
        }

        public void addFlightData(FlightRoute flightRoute)
        {
            _scheduledFlight.SetAircraftForRoute(new Plane { Id = 217, Name = "PIA Plane", NumberOfSeats = 18 });

            _scheduledFlight.AddPassenger(new Passenger { Type = PassengerType.LoyaltyMember, Name = "Mite", Age = 60, LoyaltyPoints = 10, IsUsingLoyaltyPoints = false });
            _scheduledFlight.AddPassenger(new Passenger { Type = PassengerType.General, Name = "Kamran", Age = 21 });
            _scheduledFlight.AddPassenger(new Passenger { Type = PassengerType.General, Name = "Amir", Age = 22});
            _scheduledFlight.AddPassenger(new Passenger { Type = PassengerType.AirlineEmployee, Name = "Kate", Age = 21 });
            _scheduledFlight.AddPassenger(new Passenger { Type = PassengerType.General, Name = "Chris", Age = 27 });
            _scheduledFlight.AddPassenger(new Passenger { Type = PassengerType.LoyaltyMember, Name = "Micheal", Age = 24, LoyaltyPoints = 2000, IsUsingLoyaltyPoints = true });
            _scheduledFlight.AddPassenger(new Passenger { Type = PassengerType.Discounted, Name = "Heeps", Age = 32 });

        }

        public int getBookedSeats()
        {
            return _scheduledFlight.Passengers.Count();
        }

        public int GetPassengersCountByType(PassengerType type)
        {
            return _scheduledFlight.Passengers.Where(o => o.Type == type).ToList().Count();
        }

    }
}
