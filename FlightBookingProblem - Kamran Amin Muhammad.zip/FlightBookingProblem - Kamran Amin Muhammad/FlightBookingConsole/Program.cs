﻿using System;
using FlightBooking.Core;

namespace FlightBookingProblem
{
    class Program
    {
        private static ScheduledFlight _scheduledFlight ;

        static void Main(string[] args)
        {
            SetupAirlineData();
            // Creating reference for calling of non static method from a static class
            Program MainProgram = new Program();   
            string command = "";
            do
            {
                command = Console.ReadLine() ?? "";
                var enteredText = command.ToLower();
                if (enteredText.Contains("print summary"))
                {
                    // if you want to switch to relaxed rules then set below value to TRUE
                    bool applyRelaxedRules = false;
                    Console.WriteLine(_scheduledFlight.GetSummary(applyRelaxedRules));
                }
                else
                {
                    string[] passengerSegments = enteredText.Split(' ');
                    if (enteredText.Contains("add general"))
                    {
                        _scheduledFlight.AddPassenger(_scheduledFlight.CreatePassengerObject(PassengerType.General, passengerSegments[2], Convert.ToInt32(passengerSegments[3])));

                    }
                    else if (enteredText.Contains("add loyalty"))
                    {
                        _scheduledFlight.AddPassenger(_scheduledFlight.CreatePassengerObject(PassengerType.LoyaltyMember, passengerSegments[2], Convert.ToInt32(passengerSegments[3]), Convert.ToInt32(passengerSegments[4]), Convert.ToBoolean(passengerSegments[5])));

                    }
                    else if (enteredText.Contains("add airline"))
                    {
                        _scheduledFlight.AddPassenger(_scheduledFlight.CreatePassengerObject(PassengerType.AirlineEmployee, passengerSegments[2], Convert.ToInt32(passengerSegments[3])));

                    }
                    else if (enteredText.Contains("add discounted"))
                    {
                        _scheduledFlight.AddPassenger(_scheduledFlight.CreatePassengerObject(PassengerType.Discounted, passengerSegments[2], Convert.ToInt32(passengerSegments[3])));

                    }
                    else if (enteredText.Contains("exit"))
                    {
                        Environment.Exit(1);
                    }
                    else
                    {
                        MainProgram.ShowErrorMessage("UNKNOWN INPUT");
                    }
                }
                
            } while (command != "exit");
        }

        private static void SetupAirlineData()
        {
            FlightRoute londonToParis = new FlightRoute("London", "Paris")
            {
                BaseCost = 50, 
                BasePrice = 100, 
                LoyaltyPointsGained = 5,
                MinimumTakeOffPercentage = 0.7
            };

            _scheduledFlight = new ScheduledFlight(londonToParis);

            // Adding Aircraft List 
            _scheduledFlight.AircraftsList.Add(new Plane { Id = 123, Name = "Antonov AN-2", NumberOfSeats = 12 });
            _scheduledFlight.AircraftsList.Add(new Plane { Id = 124, Name = "Bombardier Q400", NumberOfSeats = 16 });
            _scheduledFlight.AircraftsList.Add(new Plane { Id = 125, Name = "ATR 640", NumberOfSeats = 12 });

            _scheduledFlight.SetAircraftForRoute(_scheduledFlight.AircraftsList[0]);
        }

        private void ShowErrorMessage(string error)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(error);
            Console.ResetColor();
        }
    }
}
